package ornekpaket;

public class Araba {

    int kapasite;
    String renk;
    int kapi;
    int motor;

    private String calismaDurumu;

    public Araba() {
        calismaDurumu = "Duruyor";
    }

    public String calisiyorMusun() {
        return this.calismaDurumu;
    }

    public void calis() {
        System.out.println("\n\n" + renk + " renkli araç çalıştırıldı.");
        calismaDurumu = "Çalışıyor";
    }

    public void dur() {
        System.out.println("\n\n" + renk + " renkli araç durduruldu.");
        calismaDurumu = "Durduruldu";
    }

}
