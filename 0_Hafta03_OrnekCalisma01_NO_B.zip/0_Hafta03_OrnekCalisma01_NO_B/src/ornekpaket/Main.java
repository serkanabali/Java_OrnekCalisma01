package ornekpaket;

public class Main {

    public static void main(String[] args) {
//        System.out.println("Merhaba dünya!..");

        Araba sedan1 = new Araba();

        sedan1.kapasite = 5;
        sedan1.renk = "Sarı";
        sedan1.kapi = 4;
        sedan1.motor = 1200;

        Araba sedan2 = new Araba();

        sedan2.kapasite = 2;
        sedan2.renk = "Kırmızı";
        sedan2.kapi = 2;
        sedan2.motor = 5000;

        System.out.println("Arabanın kapasitesi = " + sedan1.kapasite + " rengi = " + sedan1.renk);
        System.out.println("Arabanın kapasitesi = " + sedan2.kapasite + " rengi = " + sedan2.renk);

        System.out.println("\n***\nSedan 1 çalışma durumu  = " + sedan1.calisiyorMusun());
        System.out.println("Sedan 2 çalışma durumu  = " + sedan2.calisiyorMusun());

        sedan1.calis();

        System.out.println("\n***\nSedan 1 çalışma durumu  = " + sedan1.calisiyorMusun());
        System.out.println("Sedan 2 çalışma durumu  = " + sedan2.calisiyorMusun());

        sedan1.dur();
        sedan2.calis();

        System.out.println("\n***\nSedan 1 çalışma durumu  = " + sedan1.calisiyorMusun());
        System.out.println("Sedan 2 çalışma durumu  = " + sedan2.calisiyorMusun());

    }

}
